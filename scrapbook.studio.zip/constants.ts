
import { Asset, ElementType } from './types';

export const INITIAL_STICKERS: Asset[] = [
  { id: 's1', type: ElementType.STICKER, name: 'Flower', url: 'https://picsum.photos/seed/flower1/200' },
  { id: 's2', type: ElementType.STICKER, name: 'Basket', url: 'https://picsum.photos/seed/basket/200' },
  { id: 's3', type: ElementType.STICKER, name: 'Apple', url: 'https://picsum.photos/seed/apple/200' },
  { id: 's4', type: ElementType.STICKER, name: 'Sun', url: 'https://picsum.photos/seed/sun/200' },
];

export const INITIAL_TAPES: Asset[] = [
  { id: 't1', type: ElementType.TAPE, name: 'Strawberry', url: '#ff6b6b' },
  { id: 't2', type: ElementType.TAPE, name: 'Meadow', url: '#a8e6cf' },
  { id: 't3', type: ElementType.TAPE, name: 'Lemon', url: '#ffd3b6' },
];

export const INITIAL_PAGES: any = {
  left: [
    {
      id: 'initial-photo-1',
      type: ElementType.IMAGE,
      content: 'https://picsum.photos/seed/picnic1/400/500',
      x: 15,
      y: 15,
      rotation: -3,
      scale: 1,
      zIndex: 10,
      page: 'left'
    }
  ],
  right: [
    {
      id: 'initial-photo-2',
      type: ElementType.IMAGE,
      content: 'https://picsum.photos/seed/picnic2/500/400',
      x: 10,
      y: 20,
      rotation: 5,
      scale: 1,
      zIndex: 10,
      page: 'right'
    },
    {
        id: 'initial-text-1',
        type: ElementType.TEXT,
        content: 'Sunday afternoon vibes... 🍎',
        x: 15,
        y: 65,
        rotation: -1,
        scale: 1,
        zIndex: 20,
        page: 'right'
    }
  ]
};
