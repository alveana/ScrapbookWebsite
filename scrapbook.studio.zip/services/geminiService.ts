
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getCreativeCaption = async (elementsDescription: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `I have a scrapbook page with the following items: ${elementsDescription}. Write a short, heartfelt, handwritten-style caption (max 15 words) that sounds like it was written by someone enjoying a picnic.`,
    });
    return response.text || "A beautiful day for a picnic!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "What a wonderful day!";
  }
};

export const generateCustomSticker = async (prompt: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: `Create a cute, watercolor-style scrapbook sticker of: ${prompt}. White border, simple silhouette, picnic theme.` }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Error:", error);
    return null;
  }
};
