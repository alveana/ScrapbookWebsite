
export enum ElementType {
  IMAGE = 'IMAGE',
  TEXT = 'TEXT',
  STICKER = 'STICKER',
  TAPE = 'TAPE'
}

export interface ScrapbookElement {
  id: string;
  type: ElementType;
  content: string; // URL for images/stickers, text for text elements
  x: number;
  y: number;
  rotation: number;
  scale: number;
  zIndex: number;
  page: 'left' | 'right';
  fontFamily?: string;
  metadata?: any;
}

export interface Asset {
  id: string;
  type: ElementType;
  url: string;
  name: string;
}
