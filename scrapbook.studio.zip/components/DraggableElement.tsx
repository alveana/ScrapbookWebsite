
import React, { useState, useRef, useEffect } from 'react';
import { ScrapbookElement, ElementType } from '../types';

interface DraggableElementProps {
  element: ScrapbookElement;
  onUpdate: (id: string, updates: Partial<ScrapbookElement>) => void;
  onDelete: (id: string) => void;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

const DraggableElement: React.FC<DraggableElementProps> = ({ 
  element, 
  onUpdate, 
  onDelete, 
  isSelected, 
  onSelect 
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const offset = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect(element.id);
    setIsDragging(true);
    
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    offset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      
      const parent = document.getElementById(`page-${element.page}`);
      if (!parent) return;
      
      const parentRect = parent.getBoundingClientRect();
      const newX = ((e.clientX - parentRect.left - offset.current.x) / parentRect.width) * 100;
      const newY = ((e.clientY - parentRect.top - offset.current.y) / parentRect.height) * 100;
      
      onUpdate(element.id, { x: newX, y: newY });
    };

    const handleMouseUp = () => setIsDragging(false);

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, element.id, element.page, onUpdate]);

  const style: React.CSSProperties = {
    position: 'absolute',
    left: `${element.x}%`,
    top: `${element.y}%`,
    transform: `rotate(${element.rotation}deg) scale(${element.scale})`,
    zIndex: element.zIndex,
    cursor: isDragging ? 'grabbing' : 'grab',
    userSelect: 'none',
    border: isSelected ? '2px dashed #D14D4D' : 'none',
  };

  const renderContent = () => {
    switch (element.type) {
      case ElementType.IMAGE:
        return (
          <div className="relative group">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-4 bg-white/40 backdrop-blur-sm z-10 border-x border-black/5 rotate-[-2deg]"></div>
            <img 
              src={element.content} 
              alt="Scrapbook" 
              className="w-48 h-auto border-[10px] border-white shadow-lg pointer-events-none"
            />
          </div>
        );
      case ElementType.TEXT:
        return (
          <div className="bg-white/40 backdrop-blur-sm p-4 rounded-lg shadow-inner border border-white/40 min-w-[120px] max-w-[240px]">
             <p 
               className="text-xl text-stone-900 leading-tight" 
               style={{ fontFamily: element.fontFamily || 'Handlee' }}
             >
               {element.content}
             </p>
          </div>
        );
      case ElementType.STICKER:
        return (
          <img 
            src={element.content} 
            alt="Sticker" 
            className="w-20 h-20 drop-shadow-lg sticker-white-border rounded-full bg-white/20 pointer-events-none"
          />
        );
      case ElementType.TAPE:
        return (
            <div 
              className="h-6 w-32 border-x border-black/5 opacity-80"
              style={{ backgroundColor: element.content }}
            >
                <div className="w-full h-full fruit-tape opacity-30"></div>
            </div>
        );
      default:
        return null;
    }
  };

  return (
    <div 
      style={style} 
      onMouseDown={handleMouseDown}
      className="transition-shadow duration-200"
    >
      {renderContent()}
      {isSelected && (
        <button 
          onClick={() => onDelete(element.id)}
          className="absolute -top-4 -right-4 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs shadow-md z-[100]"
        >
          ×
        </button>
      )}
    </div>
  );
};

export default DraggableElement;
