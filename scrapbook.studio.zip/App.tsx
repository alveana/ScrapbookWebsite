
import React, { useState, useCallback, useMemo } from 'react';
import { ElementType, ScrapbookElement } from './types';
import { INITIAL_PAGES, INITIAL_STICKERS, INITIAL_TAPES } from './constants';
import DraggableElement from './components/DraggableElement';
import { getCreativeCaption, generateCustomSticker } from './services/geminiService';

const AVAILABLE_FONTS = [
  { name: 'Handlee', value: "'Handlee', cursive" },
  { name: 'Gaegu', value: "'Gaegu', sans-serif" },
  { name: 'Fredoka', value: "'Fredoka One', cursive" },
  { name: 'Patrick', value: "'Patrick Hand', cursive" },
  { name: 'Marker', value: "'Permanent Marker', cursive" },
  { name: 'Indie', value: "'Indie Flower', cursive" },
];

const App: React.FC = () => {
  const [pages, setPages] = useState<{left: ScrapbookElement[], right: ScrapbookElement[]}>(INITIAL_PAGES);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('PHOTOS');
  const [isGenerating, setIsGenerating] = useState(false);
  const [stickerPrompt, setStickerPrompt] = useState('');
  const [currentFont, setCurrentFont] = useState(AVAILABLE_FONTS[0].value);
  const [targetPage, setTargetPage] = useState<'left' | 'right'>('left');

  const selectedElement = useMemo(() => {
    if (!selectedId) return null;
    return pages.left.find(e => e.id === selectedId) || pages.right.find(e => e.id === selectedId);
  }, [selectedId, pages]);

  const updateElement = useCallback((id: string, updates: Partial<ScrapbookElement>) => {
    setPages(prev => ({
      left: prev.left.map(el => el.id === id ? { ...el, ...updates } : el),
      right: prev.right.map(el => el.id === id ? { ...el, ...updates } : el),
    }));
  }, []);

  const deleteElement = useCallback((id: string) => {
    setPages(prev => ({
      left: prev.left.filter(el => el.id !== id),
      right: prev.right.filter(el => el.id !== id),
    }));
    setSelectedId(null);
  }, []);

  const addElement = (type: ElementType, content: string, page: 'left' | 'right' = targetPage) => {
    const newElement: ScrapbookElement = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      content,
      x: 20 + (Math.random() * 40),
      y: 20 + (Math.random() * 40),
      rotation: (Math.random() * 20) - 10,
      scale: 1,
      zIndex: Date.now() % 10000,
      page,
      fontFamily: type === ElementType.TEXT ? currentFont : undefined
    };
    setPages(prev => ({
      ...prev,
      [page]: [...prev[page], newElement]
    }));
  };

  const handleMagicCaption = async () => {
    setIsGenerating(true);
    const leftDesc = pages.left.map(e => e.type).join(', ');
    const rightDesc = pages.right.map(e => e.type).join(', ');
    const caption = await getCreativeCaption(`Left page items: ${leftDesc}. Right page items: ${rightDesc}`);
    addElement(ElementType.TEXT, caption, targetPage);
    setIsGenerating(false);
  };

  const handleGenerateSticker = async () => {
    if (!stickerPrompt) return;
    setIsGenerating(true);
    const stickerUrl = await generateCustomSticker(stickerPrompt);
    if (stickerUrl) {
      addElement(ElementType.STICKER, stickerUrl, targetPage);
      setStickerPrompt('');
    }
    setIsGenerating(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        addElement(ElementType.IMAGE, reader.result as string, targetPage);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFontChange = (fontValue: string) => {
    setCurrentFont(fontValue);
    if (selectedId && selectedElement?.type === ElementType.TEXT) {
      updateElement(selectedId, { fontFamily: fontValue });
    }
  };

  return (
    <div className="min-h-screen bg-picnic-white font-kids text-gray-800 gingham-bg">
      <header className="fixed top-0 left-0 right-0 h-14 bg-white/90 backdrop-blur-md border-b border-gray-200 flex items-center justify-between px-8 z-[100]">
        <div className="flex items-center gap-6">
          <span className="font-display text-primary text-xl tracking-tight">SCRAPBOOK.studio</span>
          <div className="h-5 w-px bg-gray-300"></div>
          <nav className="flex gap-6 text-[10px] font-bold uppercase tracking-widest text-gray-500">
            <button className="hover:text-primary transition-colors">My Projects</button>
            <button className="hover:text-primary transition-colors">Templates</button>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={handleMagicCaption}
            disabled={isGenerating}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-[10px] font-bold transition-all shadow-md ${isGenerating ? 'bg-gray-400 cursor-not-allowed text-white' : 'bg-amber-100 text-amber-800 hover:bg-amber-200'}`}
          >
            <span className="material-symbols-outlined text-sm">auto_fix_high</span>
            {isGenerating ? 'WORKING MAGIC...' : 'MAGIC CAPTION'}
          </button>
          <button className="px-6 py-1.5 bg-primary text-white rounded-lg text-[10px] font-bold shadow-md hover:brightness-110 transition-all">
            EXPORT
          </button>
        </div>
      </header>

      <main className="relative h-screen pt-14 flex">
        <aside className="w-32 flex flex-col items-center pt-10 gap-4 z-50">
          <button 
            onClick={() => setActiveTab('PHOTOS')}
            className={`note-tab w-24 h-24 flex flex-col items-center justify-center border shadow-sm z-40 group rotate-[-1deg] ${activeTab === 'PHOTOS' ? 'bg-white border-primary border-2' : 'bg-white border-gray-200'}`}
          >
            <span className="material-symbols-outlined text-primary group-hover:scale-110">image</span>
            <span className="text-[10px] font-bold mt-1 text-gray-500 uppercase">Photos</span>
          </button>
          <button 
            onClick={() => setActiveTab('TEXT')}
            className={`note-tab w-24 h-24 flex flex-col items-center justify-center border shadow-sm z-30 group rotate-[2deg] ${activeTab === 'TEXT' ? 'bg-[#FFF9E6] border-amber-400 border-2' : 'bg-[#FFF9E6] border-amber-100'}`}
          >
            <span className="material-symbols-outlined text-amber-700 group-hover:scale-110">draw</span>
            <span className="text-[10px] font-bold mt-1 text-amber-800/60 uppercase">Text</span>
          </button>
          <button 
            onClick={() => setActiveTab('STICKERS')}
            className={`note-tab w-24 h-24 flex flex-col items-center justify-center border shadow-sm z-20 group rotate-[-2deg] ${activeTab === 'STICKERS' ? 'bg-[#FFEAEA] border-red-400 border-2' : 'bg-[#FFEAEA] border-red-50'}`}
          >
            <span className="material-symbols-outlined text-red-400 group-hover:scale-110">category</span>
            <span className="text-[10px] font-bold mt-1 text-red-400/80 uppercase">Stickers</span>
          </button>
          <button 
            onClick={() => setActiveTab('TAPE')}
            className={`note-tab w-24 h-24 flex flex-col items-center justify-center border shadow-sm z-10 group rotate-[1deg] ${activeTab === 'TAPE' ? 'bg-[#E8F5E9] border-green-400 border-2' : 'bg-[#E8F5E9] border-green-50'}`}
          >
            <span className="material-symbols-outlined text-green-600 group-hover:scale-110">colors</span>
            <span className="text-[10px] font-bold mt-1 text-green-600/60 uppercase">Tape</span>
          </button>
        </aside>

        <div className="flex-1 flex items-center justify-center relative px-4" onClick={() => setSelectedId(null)}>
          <div className="relative w-full max-w-5xl aspect-[1.4/1] flex scale-100 lg:scale-110">
            {/* Left Page */}
            <div 
              id="page-left"
              onClick={(e) => { e.stopPropagation(); setTargetPage('left'); }}
              className={`flex-1 kraft-paper-texture paper-shadow rounded-l-3xl p-10 relative overflow-hidden transform rotate-[-0.2deg] origin-right border-r-0 cursor-pointer transition-all duration-300 ${targetPage === 'left' ? 'ring-4 ring-primary ring-inset' : ''}`}
            >
              {pages.left.map(el => (
                <DraggableElement 
                  key={el.id} 
                  element={el} 
                  onUpdate={updateElement} 
                  onDelete={deleteElement}
                  isSelected={selectedId === el.id}
                  onSelect={setSelectedId}
                />
              ))}
              <div className="absolute right-[-2.5rem] top-1/2 -translate-y-1/2 font-display text-9xl text-black/5 select-none z-0 tracking-tight">
                PIC
              </div>
            </div>

            {/* Notebook Spine */}
            <div className="w-10 notebook-spine z-50 flex flex-col justify-around py-12">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="w-5 h-5 rounded-full bg-black/10 mx-auto border border-black/5 shadow-inner"></div>
              ))}
            </div>

            {/* Right Page */}
            <div 
              id="page-right"
              onClick={(e) => { e.stopPropagation(); setTargetPage('right'); }}
              className={`flex-1 kraft-paper-texture paper-shadow rounded-r-3xl p-10 relative overflow-hidden transform rotate-[0.2deg] origin-left cursor-pointer transition-all duration-300 ${targetPage === 'right' ? 'ring-4 ring-primary ring-inset' : ''}`}
            >
              {pages.right.map(el => (
                <DraggableElement 
                  key={el.id} 
                  element={el} 
                  onUpdate={updateElement} 
                  onDelete={deleteElement}
                  isSelected={selectedId === el.id}
                  onSelect={setSelectedId}
                />
              ))}
              <div className="absolute left-[-2.5rem] top-1/2 -translate-y-1/2 font-display text-9xl text-black/5 select-none z-0 tracking-tight">
                NIC
              </div>
            </div>

            <div className="absolute -bottom-14 left-0 right-0 flex justify-between px-20 text-[10px] font-bold text-red-950/40 uppercase tracking-[0.3em]">
              <span>PAGE . 01</span>
              <span>PAGE . 02</span>
            </div>
          </div>
        </div>

        <aside className="w-80 bg-white/80 backdrop-blur-md border-l border-gray-200 h-full p-6 overflow-y-auto z-50">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">local_mall</span>
              <h3 className="font-display text-gray-800 text-sm uppercase tracking-widest">Materials</h3>
            </div>
          </div>

          <div className="mb-8 p-3 bg-gray-50 rounded-xl border border-gray-100 shadow-inner">
            <p className="text-[10px] font-bold text-gray-400 uppercase mb-3 text-center tracking-widest">Target Page</p>
            <div className="flex bg-white rounded-lg p-1 border border-gray-200 shadow-sm">
              <button 
                onClick={() => setTargetPage('left')}
                className={`flex-1 py-2 text-[10px] font-bold rounded-md transition-all ${targetPage === 'left' ? 'bg-primary text-white shadow-md' : 'text-gray-400 hover:bg-gray-50'}`}
              >
                LEFT PAGE
              </button>
              <button 
                onClick={() => setTargetPage('right')}
                className={`flex-1 py-2 text-[10px] font-bold rounded-md transition-all ${targetPage === 'right' ? 'bg-primary text-white shadow-md' : 'text-gray-400 hover:bg-gray-50'}`}
              >
                RIGHT PAGE
              </button>
            </div>
          </div>

          {activeTab === 'PHOTOS' && (
            <div className="mb-10 animate-in fade-in duration-300">
              <p className="text-[10px] font-bold text-gray-400 uppercase mb-4 tracking-widest">Add Photos</p>
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-2xl cursor-pointer hover:border-primary transition-colors bg-white">
                <span className="material-symbols-outlined text-3xl text-gray-400 mb-2">add_a_photo</span>
                <span className="text-[10px] font-bold text-gray-500 uppercase">Upload File</span>
                <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
              </label>
            </div>
          )}

          {activeTab === 'TEXT' && (
            <div className="mb-10 animate-in fade-in duration-300">
              <p className="text-[10px] font-bold text-gray-400 uppercase mb-4 tracking-widest">Journaling</p>
              <div className="mb-6">
                 <p className="text-[10px] font-bold text-gray-400 uppercase mb-3 tracking-widest">Font Style</p>
                 <div className="grid grid-cols-3 gap-2">
                   {AVAILABLE_FONTS.map(font => (
                     <button
                       key={font.name}
                       onClick={() => handleFontChange(font.value)}
                       className={`p-2 rounded-lg border text-sm transition-all hover:border-amber-400 ${(selectedElement?.fontFamily === font.value || (!selectedId && currentFont === font.value)) ? 'bg-amber-100 border-amber-400 shadow-sm' : 'bg-white border-gray-100'}`}
                       style={{ fontFamily: font.value }}
                     >
                       {font.name}
                     </button>
                   ))}
                 </div>
              </div>

              <textarea 
                className="w-full p-4 border border-amber-100 rounded-xl bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-200 mb-4 transition-all"
                style={{ fontFamily: currentFont }}
                placeholder="Write your story..."
                rows={4}
                id="manual-text"
              ></textarea>
              <button 
                onClick={() => {
                   const txt = (document.getElementById('manual-text') as HTMLTextAreaElement).value;
                   if (txt) {
                     addElement(ElementType.TEXT, txt);
                     (document.getElementById('manual-text') as HTMLTextAreaElement).value = '';
                   }
                }}
                className="w-full py-3 bg-amber-400 text-white rounded-xl font-bold text-[10px] uppercase shadow-md hover:bg-amber-500 active:scale-95 transition-all"
              >
                Add Text to {targetPage === 'left' ? 'Left' : 'Right'} Page
              </button>
            </div>
          )}

          {activeTab === 'STICKERS' && (
            <div className="mb-10 animate-in fade-in duration-300">
               <div className="mb-8">
                <p className="text-[10px] font-bold text-gray-400 uppercase mb-3 tracking-widest">AI Custom Sticker</p>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={stickerPrompt}
                    onChange={(e) => setStickerPrompt(e.target.value)}
                    placeholder="e.g. A tiny ant" 
                    className="flex-1 px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                  <button 
                    onClick={handleGenerateSticker}
                    disabled={isGenerating || !stickerPrompt}
                    className="p-2 bg-primary text-white rounded-lg disabled:opacity-50 hover:brightness-110 shadow-sm"
                  >
                    <span className="material-symbols-outlined text-lg">magic_button</span>
                  </button>
                </div>
              </div>
              <p className="text-[10px] font-bold text-gray-400 uppercase mb-4 tracking-widest">Sticker Library</p>
              <div className="grid grid-cols-2 gap-4">
                {INITIAL_STICKERS.map(s => (
                  <button 
                    key={s.id}
                    onClick={() => addElement(ElementType.STICKER, s.url)}
                    className="aspect-square bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center p-3 hover:scale-105 active:scale-95 transition-all group"
                  >
                    <img src={s.url} alt={s.name} className="w-14 h-14 mb-1 rounded-md object-cover" />
                    <span className="text-[8px] text-gray-400 font-bold group-hover:text-primary uppercase">{s.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'TAPE' && (
             <div className="mb-10 animate-in fade-in duration-300">
             <p className="text-[10px] font-bold text-gray-400 uppercase mb-4 tracking-widest">Washi Tapes</p>
             <div className="grid grid-cols-1 gap-4">
               {INITIAL_TAPES.map(t => (
                 <button 
                   key={t.id}
                   onClick={() => addElement(ElementType.TAPE, t.url)}
                   className="h-10 w-full rounded-sm shadow-sm flex items-center justify-center overflow-hidden transition-all hover:scale-[1.02] active:scale-95"
                   style={{ backgroundColor: t.url }}
                 >
                   <div className="w-full h-full fruit-tape opacity-30 flex items-center justify-center">
                     <span className="text-[8px] font-bold text-black/20 uppercase tracking-[0.2em]">{t.name}</span>
                   </div>
                 </button>
               ))}
             </div>
           </div>
          )}

          <div className="mt-auto pt-6 border-t border-gray-100">
            <div className="p-4 bg-primary/5 border border-primary/10 rounded-xl relative overflow-hidden group">
               <div className="absolute inset-0 bg-primary opacity-0 group-hover:opacity-[0.03] transition-opacity"></div>
               <p className="font-hand text-sm text-primary/80">"Capture the sunny days, one page at a time."</p>
            </div>
          </div>
        </aside>
      </main>

      <div className="fixed bottom-6 left-8 z-[60] flex items-center gap-4">
        <button className="bg-white p-4 rounded-full shadow-2xl border border-gray-100 hover:scale-110 active:scale-90 transition-all text-primary">
          <span className="material-symbols-outlined">local_florist</span>
        </button>
        <div className="bg-white/90 backdrop-blur-sm px-5 py-2.5 rounded-full border border-gray-100 shadow-xl flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Editing {targetPage === 'left' ? 'Page 1' : 'Page 2'}</span>
        </div>
      </div>
    </div>
  );
};

export default App;
